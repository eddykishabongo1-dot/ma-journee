# Ma Journée — projet Android (APK)

Ce projet enveloppe l'interface hors ligne dans une application Android et ajoute un pont de programmation des rappels Android. Il est fourni en code source ; aucun APK compilé n'est inclus dans cette archive.

## Compiler gratuitement avec GitHub Actions
1. Crée un dépôt GitHub vide.
2. Téléverse le contenu de ce dossier à la racine du dépôt (y compris `.github/workflows/build-apk.yml`).
3. Ouvre l'onglet **Actions** du dépôt et lance **Build Ma Journee APK** avec **Run workflow**, ou fais un commit sur la branche `main`.
4. Lorsque l'exécution est terminée, ouvre le workflow réussi et télécharge l'artefact **ma-journee-apk**.
5. Décompresse l'artefact téléchargé : il contient `app-debug.apk`.
6. Transfère le fichier APK sur ton téléphone Android et ouvre-le. Si Android le demande, autorise temporairement l'installation depuis cette source.

## Remarques
- Le code source n'a pas pu être compilé ni testé dans l'environnement de création ; la compilation GitHub Actions permet de vérifier le résultat.
- Android peut limiter ou retarder les alarmes en mode économie d'énergie. Les rappels sont programmés comme alarmes autorisées en veille, mais ils ne sont pas des alarmes exactes garanties.
- Les notifications nécessitent l'autorisation Android 13+.
- Les données de l'application sont stockées localement dans le WebView. Fais régulièrement une exportation de sauvegarde depuis l'application.
