package com.majournee.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.ArrayList;

public class AlarmScheduler {
    static final String PREFS = "ma_journee_alarms";
    public static void schedule(Context c, String id, String title, String body, long at, boolean alarm) {
        int requestCode = id.hashCode();
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("title", title); i.putExtra("body", body); i.putExtra("alarm", alarm); i.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(c, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
        c.getSharedPreferences(PREFS, 0).edit().putInt("id_" + requestCode, requestCode).apply();
    }
    public static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        android.content.SharedPreferences p = c.getSharedPreferences(PREFS, 0);
        for (String key : p.getAll().keySet()) {
            if (!key.startsWith("id_")) continue;
            int rc = p.getInt(key, 0);
            Intent i = new Intent(c, AlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, rc, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (am != null && pi != null) am.cancel(pi);
        }
        p.edit().clear().apply();
    }
}
