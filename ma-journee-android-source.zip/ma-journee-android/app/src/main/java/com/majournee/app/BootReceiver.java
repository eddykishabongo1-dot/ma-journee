package com.majournee.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // The app re-synchronizes its reminders when opened. Persistent rescheduling is planned for a later release.
    }
}
